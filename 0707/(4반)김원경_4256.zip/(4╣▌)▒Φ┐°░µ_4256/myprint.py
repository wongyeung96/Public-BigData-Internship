#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# !/usr/bin/env python
# coding: utf-8

def print1(st):
    print("*" * 50)
    print(st)
    print('*' * 50)
    
def print2(st):
    print('-' * 50)
    print(st)
    print('-' * 50)

